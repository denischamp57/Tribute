# Tribute Page — My Dad

This project is a simple **tribute webpage** created with semantic **HTML5** and a touch of **CSS**.  
It is dedicated to my dad, honoring his life, values, and legacy.

## Features
- Responsive design with semantic HTML elements (`header`, `nav`, `main`, `article`, `aside`, `footer`).
- A timeline of important life stages.
- Blockquotes and personal notes.
- Minimal CSS for clean and modern styling.

## How to Run
1. Clone this repository:
   ```bash
   git clone https://github.com/your-username/tribute-page.git
   ```
2. Navigate to the folder:
   ```bash
   cd tribute-page
   ```
3. Open `index.html` in your browser.

## Deployment
You can deploy this project easily with **GitHub Pages**:
- Go to **Settings → Pages**.
- Set branch to `main` and root folder `/`.
- Save and access the live site at:
  ```
  https://your-username.github.io/tribute-page/
  ```

## License
This project is shared for educational and personal use.
